#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>
#include <time.h>
#include <pwd.h>
#include <grp.h>
#include <errno.h>
#include <string.h>

// Function prototypes
void printFileMode(mode_t mode);
void printFormattedTime(const char *label, time_t timeVal);

void printFileMode(mode_t mode) {
    char type = S_ISLNK(mode) ? 'l' : S_ISDIR(mode) ? 'd' : S_ISCHR(mode) ? 'c' :
                S_ISBLK(mode) ? 'b' : S_ISREG(mode) ? '-' : S_ISFIFO(mode) ? 'p' :
                S_ISSOCK(mode) ? 's' : '?';

    char str[11];
    mode_t permBits;

    str[0] = type;
    str[1] = (mode & S_IRUSR) ? 'r' : '-';
    str[2] = (mode & S_IWUSR) ? 'w' : '-';
    str[3] = (mode & S_IXUSR) ? 'x' : '-';
    str[4] = (mode & S_IRGRP) ? 'r' : '-';
    str[5] = (mode & S_IWGRP) ? 'w' : '-';
    str[6] = (mode & S_IXGRP) ? 'x' : '-';
    str[7] = (mode & S_IROTH) ? 'r' : '-';
    str[8] = (mode & S_IWOTH) ? 'w' : '-';
    str[9] = (mode & S_IXOTH) ? 'x' : '-';
    str[10] = '\0';

    permBits = mode & (S_IRWXU | S_IRWXG | S_IRWXO);
    printf("  Mode:\t\t\t\t%s\t\t(%03o in octal)\n", str, permBits);
}
/* 
void printFormattedTime(const char *label, time_t timeVal) {
    struct tm *local;
    struct tm *gmt;
    char localBuf[128];
    char gmtBuf[128];

    printf("  %-24s %ld (seconds since the epoch)\n", label, (long)timeVal);

    local = localtime(&timeVal);
    strftime(localBuf, sizeof(localBuf), "%Y-%m-%d %H:%M:%S %z (%Z) %a", local);
    printf("  %-24s %s (local)\n", label, localBuf);

    gmt = gmtime(&timeVal);
    strftime(gmtBuf, sizeof(gmtBuf), "%Y-%m-%d %H:%M:%S %z (%Z) %a", gmt);
    printf("  %-24s %s (GMT)\n", label, gmtBuf);
}
*/
int main(int argc, char *argv[]) {
    struct stat fileStat;
    struct stat fileStats;
    struct passwd *pwd;
    struct group *grp;
    char timeBuf[80];

    if (argc != 2) {
        fprintf(stderr, "Usage: %s <pathname>\n", argv[0]);
        return 1;
    }

    if (lstat(argv[1], &fileStat) != 0) {
        perror("lstat");
        return 1;
    }

    if (S_ISLNK(fileStat.st_mode)) {
        char targetPath[1024];
        int len = readlink(argv[1], targetPath, sizeof(targetPath) - 1);
        if (len < 0) {
            perror("readlink");
            return 1;
        }

        targetPath[len] = '\0';

        if (stat(argv[1], &fileStats) < 0) {
            if (errno == ENOENT) {
                printf("File: %s\n", argv[1]);
                printf("  File type: \t\t\tSymbolic link - with dangling destination\n");
            } else {
                perror("stat");
                return 1;
            }
        } else {
            printf("File: %s\n", argv[1]);
            printf("  File type: \t\t\tSymbolic link -> %s\n", targetPath);
        }
    } else {
        printf("File: %s\n", argv[1]);
        printf("  File type: \t\t\t");

        switch (fileStat.st_mode & S_IFMT) {
            case S_IFBLK:  printf("block device\n"); break;
            case S_IFCHR:  printf("character device\n"); break;
            case S_IFDIR:  printf("directory\n"); break;
            case S_IFIFO:  printf("FIFO/pipe\n"); break;
            case S_IFREG:  printf("regular file\n"); break;
            case S_IFSOCK: printf("socket\n"); break;
            default:       printf("unknown?\n"); break;
        }
    }
    printf("  Device ID number:\t\t%ld\n", (long) fileStat.st_dev);
   printf("  I-node number:\t\t%ld\n", (long)fileStat.st_ino);
   printFileMode(fileStat.st_mode);
   printf("  Link count:\t\t\t%ld\n", (long)fileStat.st_nlink);

   pwd = getpwuid(fileStat.st_uid);
   grp = getgrgid(fileStat.st_gid);
   printf("  Owner Id:\t\t\t%s\t\t(UID = %ld)\n", pwd ? pwd->pw_name : "UNKNOWN", (long)fileStat.st_uid);
   printf("  Group Id:\t\t\t%s\t\t(GID = %ld)\n", grp ? grp->gr_name : "UNKNOWN", (long)fileStat.st_gid);

   printf("  Preferred I/O block size:\t%ld bytes\n", (long)fileStat.st_blksize);
   printf("  File size:\t\t\t%lld bytes\n", (long long)fileStat.st_size);
   printf("  Blocks allocated:\t\t%lld\n", (long long)fileStat.st_blocks);

   // Seconds since epoch
   printf("  Last file access:         %ld (seconds since the epoch)\n", fileStat.st_atime);
   printf("  Last file modification:   %ld (seconds since the epoch)\n", fileStat.st_mtime);
   printf("  Last status change:       %ld (seconds since the epoch)\n", fileStat.st_ctime);

   // Local time
   strftime(timeBuf, sizeof(timeBuf), "%Y-%m-%d %H:%M:%S %z (%Z) %a", localtime(&fileStat.st_atime));
   printf("  Last file access:         %s (local)\n", timeBuf);
   strftime(timeBuf, sizeof(timeBuf), "%Y-%m-%d %H:%M:%S %z (%Z) %a", localtime(&fileStat.st_mtime));
   printf("  Last file modification:   %s (local)\n", timeBuf);
   strftime(timeBuf, sizeof(timeBuf), "%Y-%m-%d %H:%M:%S %z (%Z) %a", localtime(&fileStat.st_ctime));
   printf("  Last status change:       %s (local)\n", timeBuf);

   // GMT time
   strftime(timeBuf, sizeof(timeBuf), "%Y-%m-%d %H:%M:%S %z (%Z) %a", gmtime(&fileStat.st_atime));
   printf("  Last file access:         %s (GMT)\n", timeBuf);
   strftime(timeBuf, sizeof(timeBuf), "%Y-%m-%d %H:%M:%S %z (%Z) %a", gmtime(&fileStat.st_mtime));
   printf("  Last file modification:   %s (GMT)\n", timeBuf);
   strftime(timeBuf, sizeof(timeBuf), "%Y-%m-%d %H:%M:%S %z (%Z) %a", gmtime(&fileStat.st_ctime));
   printf("  Last status change:       %s (GMT)\n", timeBuf);



    return 0;
}

