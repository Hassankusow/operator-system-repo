#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#define OPTIONS "k:"

#define BUF_SIZE 50000
#define DELIMITERS " ()\n"

#ifdef NOISY_DEBUG
# define NOISY_DEBUG_PRINT fprintf(stderr, "%s %s %   d\ n", __FILE__, __func__, __LINE__)
#else // NOISY_DEBUG
# define NOISY_DEBUG_PRINT
#endif // NOISY_DEBUG

void xor_stream(const char *key);


void xor_stream(const char *key){
    char buffer[BUF_SIZE];
    ssize_t bytes_read;
    size_t key_len = strlen(key);
    size_t key_index = 0;

    while((bytes_read = read(STDIN_FILENO, buffer, BUF_SIZE)) > 0) {
            for (ssize_t i = 0; i < bytes_read; i++) {
                    buffer[i] ^= key[key_index % key_len];
                    key_index++;
            }
            write(STDOUT_FILENO, buffer, bytes_read);
    }


}

int main(int argc, char *argv[]) {
        int opt = -1;
        char *key = "Xerographic";

        while ((opt = getopt(argc, argv, OPTIONS)) != -1) {
                 switch (opt) {
                         case 'k':
                                 key = optarg;
                                 break;
                         default:
                                 const char *usage = "Usage: ./xor [-k key]\n";
                                 write(STDERR_FILENO, usage, strlen(usage));
                                 exit(EXIT_FAILURE);
                 }
        }
        xor_stream(key);


        return EXIT_SUCCESS;
}
