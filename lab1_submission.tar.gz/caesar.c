#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#define OPTIONS "eds:"

#ifndef FALSE
# define FALSE 0
#endif //FALSE
#ifndef TRUE
# define TRUE 1
#endif //TRUE
#define BUF_SIZE 50000
#define DELIMITERS " ()\n"

#ifdef NOISY_DEBUG
# define NOISY_DEBUG_PRINT fprintf(stderr, "%s %s %   d\ n", __FILE__, __func__, __LINE__)
#else // NOISY_DEBUG
# define NOISY_DEBUG_PRINT
#endif // NOISY_DEBUG

#define DEFAULT_SHIFT 3
#define MIN_SHIFT 0
#define MAX_SHIFT 95

#define ASCII_MIN 32
#define ASCII_MAX 126
#define ASCII_RANGE (ASCII_MAX - ASCII_MIN + 1)

char encrypt_char(char ch, int shift);
char decrypt_char(char ch, int shift);
void process_stream(int encrypt, int shift);

char encrypt_char(char ch, int shift) {
    if (ch >= ASCII_MIN && ch <= ASCII_MAX)
        return ((ch - ASCII_MIN + shift) % ASCII_RANGE) + ASCII_MIN;
    return ch; 
}

char decrypt_char(char ch, int shift) {
    if (ch >= ASCII_MIN && ch <= ASCII_MAX)
        return ((ch - ASCII_MIN - shift + ASCII_RANGE) % ASCII_RANGE) + ASCII_MIN;
    return ch;
}



void process_stream(int encrypt, int shift) {
    char buf[BUF_SIZE];
    ssize_t bytes_read;

    while ((bytes_read = read(STDIN_FILENO, buf, BUF_SIZE)) > 0) {
        for (ssize_t i = 0; i < bytes_read; i++) {
            buf[i] = encrypt ? encrypt_char(buf[i], shift)
                             : decrypt_char(buf[i], shift);
        }
        if (write(STDOUT_FILENO, buf, bytes_read) < 0) {
            perror("write");
            exit(EXIT_FAILURE);
        }
    }

    if (bytes_read < 0) {
        perror("read");
        exit(EXIT_FAILURE);
    }
}


int main(int argc, char *argv[]) {
    int encrypt = TRUE;
    int shift = DEFAULT_SHIFT;
    int opt;

    int e_flag = FALSE;
    int d_flag = FALSE;

    while ((opt = getopt(argc, argv, OPTIONS)) != -1) {
        switch (opt) {
            case 'e':
                e_flag = TRUE;
                break;
            case 'd':
                d_flag = TRUE;
                break;
            case 's': {
                char *endptr;
                shift = strtol(optarg, &endptr, 10);
                if (*endptr != '\0') {
                    fprintf(stderr, "Invalid shift value: %s\n", optarg);
                    exit(EXIT_FAILURE);
                }
                if (shift < MIN_SHIFT || shift > MAX_SHIFT) {
                    fprintf(stderr, "Shift must be between %d and %d.\n", MIN_SHIFT, MAX_SHIFT);
                    exit(EXIT_FAILURE);
                }
                break;
            }
            default:
                fprintf(stderr, "Usage: %s [-e|-d] [-s shift]\n", argv[0]);
                exit(EXIT_FAILURE);
        }
    }
    if(e_flag){};
    if (d_flag) {
        encrypt = FALSE;
    } else {
        encrypt = TRUE;
    }

    process_stream(encrypt, shift);
    return EXIT_SUCCESS;
}

