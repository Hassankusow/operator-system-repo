#include <stdio.h>
#include <getopt.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <semaphore.h>

#ifndef MAX_DIM
# define MAX_DIM 4000
#endif

#ifndef DEF_DIM
# define DEF_DIM 1000
#endif

#define MICROSECONDS_PER_SECOND 1000000.0

#define ELEMENT(_mat,_x,_y,_cols) _mat[(_x * _cols) + _y]
#define MATRIX_SIZE (dim * dim * sizeof(float))
#define SHM_SIZE (MATRIX_SIZE)

static float *matrix1 = NULL;
static float *matrix2 = NULL;
static float *result = NULL;
static int dim = DEF_DIM;
static int num_procs = 1;
static int shmfd = -1;
static void *shm_mem = NULL;

void init(float *, float *, float *, int);
void op_mat(float *, int);
void mult(void);
double elapse_time(struct timeval *, struct timeval *);

int main(int argc, char *argv[]) {
    int opt = -1;
    struct timeval et0, et1, et2, et3, et4, et5;
    char shm_name[256] = {'\0'};
    int ret_val = 0;

    while ((opt = getopt(argc, argv, "p:d:h")) != -1) {
        switch (opt) {
            case 'p':
                num_procs = atoi(optarg);
                break;
            case 'd':
                dim = atoi(optarg);
                if (dim < DEF_DIM) dim = DEF_DIM;
                if (dim > MAX_DIM) dim = MAX_DIM;
                break;
            case 'h':
                printf("%s: -p # -d #\n", argv[0]);
                printf("\t-p #: number of processes\n");
                printf("\t-d #: size of matrix\n");
                exit(0);
                break;
            default:
                exit(EXIT_FAILURE);
        }
    }

    gettimeofday(&et0, NULL);
    matrix1 = malloc(MATRIX_SIZE);
    matrix2 = malloc(MATRIX_SIZE);

    sprintf(shm_name, "%s.%s", "/SharedMem_MatrixMult_", getenv("LOGNAME"));
    if (shm_unlink(shm_name) != 0) {
    }

    shmfd = shm_open(shm_name, (O_CREAT | O_RDWR | O_EXCL), (S_IRUSR | S_IWUSR));
    if (shmfd < 0) {
        fprintf(stderr, "failed to open/create shared memory segment >%s<\n", shm_name);
        exit(3);
    }

    ret_val = ftruncate(shmfd, SHM_SIZE);
    if (ret_val != 0) {
        fprintf(stderr, "failed to size shared memory\n");
        exit(4);
    }

    shm_mem = mmap(NULL, SHM_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, shmfd, 0);
    result = (float *) shm_mem;

    gettimeofday(&et1, NULL);
    init(matrix1, matrix2, result, dim);
    gettimeofday(&et2, NULL);
    mult();
    gettimeofday(&et3, NULL);
    op_mat(result, dim);
    gettimeofday(&et4, NULL);

    free(matrix1);
    free(matrix2);
    munmap(shm_mem, SHM_SIZE);
    close(shmfd);
    shm_unlink(shm_name);
    matrix1 = matrix2 = result = NULL;

    gettimeofday(&et5, NULL);
    {
        double total_time = elapse_time(&et0, &et5);
        double alloc_time = elapse_time(&et0, &et1);
        double init_time = elapse_time(&et1, &et2);
        double comp_time = elapse_time(&et2, &et3);
        double op_time = elapse_time(&et3, &et4);
        double td_time = elapse_time(&et4, &et5);

        printf("Total time: %8.2lf dim: %d processes: %d\n", total_time, dim, num_procs);
        printf(" Alloc time: %8.2lf\n", alloc_time);
        printf(" Init  time: %8.2lf\n", init_time);
        printf(" Comp  time: %8.2lf\n", comp_time);
        printf(" O/P   time: %8.2lf\n", op_time);
        printf(" T/D   time: %8.2lf\n", td_time);
    }

    return EXIT_SUCCESS;
}

void init(float *mat1, float *mat2, float *res, int d) {
    for (int i = 0; i < d; i++) {
        for (int j = 0; j < d; j++) {
            ELEMENT(mat1, i, j, d) = (i + j) * 2.0;
            ELEMENT(mat2, i, j, d) = (i + j) * 3.0;
            ELEMENT(res, i, j, d) = 0.0;
        }
    }
}

void op_mat(float *mat1, int d) {
    FILE *op = NULL;
    const char *FILE_NAME = "mm5.txt";

    op = fopen(FILE_NAME, "w");
    if (op == NULL) {
        perror("could not open file: mm3.txt");
        exit(17);
    }

    for (int i = 0; i < d; i++) {
        for (int j = 0; j < d; j++) {
            fprintf(op, "%8.2f ", ELEMENT(mat1, i, j, d));
        }
        fprintf(op, "\n");
    }

    fclose(op);
}

double elapse_time(struct timeval *t0, struct timeval *t1) {
    return ((double)(t1->tv_usec - t0->tv_usec)) / MICROSECONDS_PER_SECOND
           + ((double)(t1->tv_sec - t0->tv_sec));
}

void mult(void) {
    int proc = 0;
    pid_t cpid = -1;

    for (proc = 0; proc < num_procs; proc++) {
        cpid = fork();
        if (cpid == 0) {
            int i = -1, j = -1, k = -1;

            for (i = proc; i < dim; i += num_procs) {
                for (j = 0; j < dim; j++) {
                    for (k = 0; k < dim; k++) {
                        ELEMENT(result, i, j, dim) +=
                            ELEMENT(matrix1, i, k, dim) * ELEMENT(matrix2, k, j, dim);
                    }
                }
            }

            fflush(stderr);
            munmap(shm_mem, SHM_SIZE);
            close(shmfd);
            _exit(EXIT_SUCCESS);
        }
    }

    fprintf(stderr, "all child process created\n");
    while ((cpid = wait(NULL)) > 0) {
        fprintf(stderr, "\tchild process %d reaped\n", cpid);
    }
    fprintf(stderr, "all child process reaped\n");
}

