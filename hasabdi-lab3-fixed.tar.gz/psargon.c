//psargon.c - CS333 Lab 3 Starter

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <argon2.h>
#include <getopt.h>
#include <errno.h>

#define MAX_THREADS 16

// Globals
static char **hashes = NULL;
static char **passwords = NULL;
static size_t num_hashes = 0;
static size_t num_passwords = 0;
static int thread_count = 1;
static FILE *log_stream = NULL;
static FILE *out_stream = NULL;
static char **output_lines = NULL;

static int next_hash = 0;
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
static int verbose = 0;

typedef struct {
    int tid;
    int cracked;
    int failed;
} thread_info_t;

// Function declarations
void *crack_thread(void *arg);
int get_next_hash(void);
char **read_lines(const char *filename, size_t *count);
void free_lines(char **lines, size_t count);
void usage(const char *prog);

int main(int argc, char *argv[]) {
    char *hash_file = NULL;
    char *pass_file = NULL;
    char *out_file = NULL;
    char *log_file = NULL;
    size_t i;
    int total_cracked = 0, total_failed = 0;
    pthread_t threads[MAX_THREADS];
    thread_info_t infos[MAX_THREADS];

    int opt;
    while ((opt = getopt(argc, argv, "h:p:o:l:t:vH")) != -1) {
        switch (opt) {
            case 'h': hash_file = optarg; break;
            case 'p': pass_file = optarg; break;
            case 'o': out_file = optarg; break;
            case 'l': log_file = optarg; break;
            case 't': thread_count = atoi(optarg); break;
            case 'v': verbose = 1; break;
            case 'H': usage(argv[0]); exit(0); break;
            default: usage(argv[0]); exit(1);
        }
    }

    if (!hash_file || !pass_file) {
        fprintf(stderr, "Error: -h and -p are required.\n");
        usage(argv[0]);
        exit(1);
    }
    if (thread_count < 1) thread_count = 1;
    if (thread_count > MAX_THREADS) thread_count = MAX_THREADS;

    if (out_file) {
            out_stream = fopen(out_file, "w");
            if (!out_stream) {
                    perror("fopen out_file");
                    exit(1);
            }
    } else {
            out_stream = stdout;
    }
    if (log_file) {
            log_stream = fopen(log_file, "w");
            if (!log_stream) {
                    perror("fopen log_file");
                    exit(1);
            }
    }else {
            log_stream = stderr;
    }

    hashes = read_lines(hash_file, &num_hashes);
    passwords = read_lines(pass_file, &num_passwords);
    output_lines = calloc(num_hashes, sizeof(char *));

    for (i = 0; i < (size_t)thread_count; i++) {
        infos[i].tid = i;
        infos[i].cracked = 0;
        infos[i].failed = 0;
        pthread_create(&threads[i], NULL, crack_thread, &infos[i]);
    }

    for (i = 0; i < (size_t)thread_count; i++) {
        pthread_join(threads[i], NULL);
    }
    for (i = 0; i < num_hashes; i++) {
            if (output_lines[i]) {
                    fputs(output_lines[i], out_stream);
                    free(output_lines[i]);
            }
    }
    free(output_lines);

    for (i = 0; i < (size_t)thread_count; i++) {
        total_cracked += infos[i].cracked;
         total_failed += infos[i].failed;
    }
    fprintf(out_stream, "TOTALS:");
    for (i = 0; i < (size_t)thread_count; i++) {
            fprintf(out_stream, " t%ld:%d/%d", i, infos[i].cracked, infos[i].failed);
    }
    fprintf(out_stream, "    TOTAL:%d/%d\n", total_cracked, total_failed);

  //   fprintf(out_stream, "TOTALS: t0:%d/%d    TOTAL:%d/%d\n", total_cracked, total_failed, total_cracked, total_failed);
    free_lines(hashes, num_hashes);
    free_lines(passwords, num_passwords);
    if (log_file) fclose(log_stream);
    fflush(out_stream);
    if (out_file) fclose(out_stream);
    return 0;
}

void *crack_thread(void *arg) {
    thread_info_t *info = (thread_info_t *)arg;
    int idx;

    while ((idx = get_next_hash()) < (int)num_hashes) {
        int matched = 0;
        for (size_t j = 0; j < num_passwords; j++) {
            if (verbose) {
                fprintf(log_stream, "Thread %d trying %s against %s\n", info->tid, passwords[j], hashes[idx]);
            }

            if (argon2_verify(hashes[idx], passwords[j], strlen(passwords[j]), Argon2_id) == ARGON2_OK) {
                char buf[2048];
                snprintf(buf, sizeof(buf), "CRACKED: %s %s\n", passwords[j], hashes[idx]);

                pthread_mutex_lock(&lock);
                if (output_lines[idx] == NULL) {
                output_lines[idx] = strdup(buf);
                info->cracked++;
                }
                pthread_mutex_unlock(&lock);

                
                matched = 1;
                break;
            }
        }

        if (!matched) {
            char buf[2048];
            snprintf(buf, sizeof(buf), "FAILED: %s\n", hashes[idx]);

            pthread_mutex_lock(&lock);
            if (output_lines[idx] == NULL) {
            output_lines[idx] = strdup(buf);
            info->failed++;
            }
            pthread_mutex_unlock(&lock);

            
        }
    }

    pthread_exit(NULL);
}

int get_next_hash(void) {
    int cur;
    pthread_mutex_lock(&lock);
    cur = next_hash++;
    pthread_mutex_unlock(&lock);
    return cur;
}

char **read_lines(const char *filename, size_t *count) {
    FILE *fp = fopen(filename, "r");
    size_t cap = 100;
    char **lines;
    char buf[1024];

    if (!fp) {
        perror("fopen");
        exit(1);
    }

    *count = 0;
    lines = malloc(cap * sizeof(char *));

    while (fgets(buf, sizeof(buf), fp)) {
        if (*count >= cap) {
            cap *= 2;
            lines = realloc(lines, cap * sizeof(char *));
        }
        buf[strcspn(buf, "\n")] = 0;
        lines[*count] = strdup(buf);
        (*count)++;
    }
    fclose(fp);
    return lines;
}

void free_lines(char **lines, size_t count) {
    for (size_t i = 0; i < count; i++) free(lines[i]);
    free(lines);
}

void usage(const char *prog) {
    fprintf(stderr,
        "Usage: %s -h hashfile -p passfile [-o outfile] [-l logfile] [-t threads] [-v] [-H]\n",
        prog);
}
