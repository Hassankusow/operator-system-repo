// psurup_server.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/sysinfo.h>
#include <sys/utsname.h>
#include <arpa/inet.h>

#define MAXLINE 1024
#define DEFAULT_PORT 10011

void usage(const char *prog);
int check_api_key(const char *key, const char *keyfile);

int check_api_key(const char *key, const char *keyfile) {
    FILE *fp;
    char line[512];
    char *colon;
    size_t len;

    fp = fopen(keyfile, "r");
    if (!fp) return 0;

    while (fgets(line, sizeof(line), fp)) {
        colon = strchr(line, ':');
        if (!colon) continue;
        *colon = '\0';
        len = strlen(colon + 1);
        if (colon[1 + len - 1] == '\n') colon[1 + len - 1] = '\0';

        if (strcmp(colon + 1, key) == 0) {
            fclose(fp);
            return 1;
        }
    }

    fclose(fp);
    return 0;
}

void usage(const char *prog) {
    fprintf(stderr, "Usage: %s -a keyfile [-p port] [-v]\n", prog);
    exit(EXIT_FAILURE);
}

int main(int argc, char *argv[]) {
    int port, verbose, sockfd, bytes, opt, procs;
    char keyfile[512], buffer[MAXLINE], out[512], *key;
    struct sockaddr_in servaddr, cliaddr;
    socklen_t len;
    struct sysinfo si;
    struct utsname uname_buf;
    long totalram, freeram, sharedram, uptime;
    double load1, load5, load15;

    port = DEFAULT_PORT;
    verbose = 0;
    sockfd = 0;
    keyfile[0] = '\0';
    len = sizeof(cliaddr);

    while ((opt = getopt(argc, argv, "a:p:vh")) != -1) {
        switch (opt) {
            case 'a':
                strncpy(keyfile, optarg, sizeof(keyfile) - 1);
                break;
            case 'p':
                port = atoi(optarg);
                break;
            case 'v':
                verbose = 1;
                break;
            case 'h':
            default:
                usage(argv[0]);
        }
    }

    if (strlen(keyfile) == 0) {
        usage(argv[0]);
    }

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(port);
    servaddr.sin_addr.s_addr = INADDR_ANY;

    if (bind(sockfd, (struct sockaddr *)&servaddr, sizeof(servaddr)) < 0) {
        perror("bind");
        exit(EXIT_FAILURE);
    }

    if (verbose) {
        printf("psurup_server listening on port %d\n", port);
        fflush(stdout);
    }

    while (1) {
        memset(buffer, 0, sizeof(buffer));
        bytes = recvfrom(sockfd, buffer, sizeof(buffer) - 1, 0,
                         (struct sockaddr *)&cliaddr, &len);
        if (bytes <= 0) {
            continue;
        }

        buffer[bytes] = '\0';

        if (strncmp(buffer, "psurup ", 7) != 0) {
            continue;
        }

        key = buffer + 7;
        if (!check_api_key(key, keyfile)) {
            continue;
        }

        sysinfo(&si);
        uname(&uname_buf);

        uptime = si.uptime;
        load1 = si.loads[0] / 65536.0;
        load5 = si.loads[1] / 65536.0;
        load15 = si.loads[2] / 65536.0;
        totalram = si.totalram / (1024 * 1024);
        freeram = si.freeram / (1024 * 1024);
        sharedram = si.sharedram / 1024;
        procs = si.procs;

        snprintf(out, sizeof(out),
                 "%s:%d: %s %ld days %02ld:%02ld:%02ld Linux %s load %.2f %.2f %.2f %ld mb RAM %ld mb free %ld kb shared %d procs\n",
                 inet_ntoa(cliaddr.sin_addr), ntohs(cliaddr.sin_port),
                 uname_buf.nodename,
                 uptime / 86400, (uptime % 86400) / 3600, (uptime % 3600) / 60, uptime % 60,
                 uname_buf.release,
                 load1, load5, load15,
                 totalram, freeram, sharedram, procs);

        sendto(sockfd, out, strlen(out), 0, (struct sockaddr *)&cliaddr, len);
    }

    close(sockfd);
    return 0;
}

