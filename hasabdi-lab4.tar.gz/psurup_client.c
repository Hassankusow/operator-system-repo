// psurup_client.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/time.h>

#define MAX_HOSTS 20
#define MAXLINE 1024
#define DEFAULT_PORT 10011
#define DEFAULT_TIMEOUT 5


void usage(const char *prog);

typedef struct host_entry {
    char hostname[256];
    int port;
    struct host_entry *next;
} host_entry_t;

void usage(const char *prog) {
    fprintf(stderr, "Usage: %s -a api_key [-H host:port]... [-t timeout] [-v]\n", prog);
    exit(EXIT_FAILURE);
}

int main(int argc, char *argv[]) {
    int opt;
    int timeout_sec = DEFAULT_TIMEOUT;
    int verbose = 0;
    int sockfd;
    struct timeval tv;
    char api_key[512] = {0};
    char *colon;
    char send_buf[MAXLINE];
    char port_str[10];
    char recv_buf[MAXLINE] = {0};
    int bytes = 0;
    socklen_t addr_len;
    host_entry_t *hosts = NULL;
    host_entry_t *tail = NULL;
    host_entry_t *cur;
    host_entry_t *new_entry;

    struct addrinfo hints;
    struct addrinfo *res;
    struct sockaddr_in *addr;
    char ip_str[INET_ADDRSTRLEN];

    while ((opt = getopt(argc, argv, "a:H:t:vh")) != -1) {
        switch (opt) {
            case 'a':
                strncpy(api_key, optarg, sizeof(api_key) - 1);
                break;
            case 'H':
                new_entry = (host_entry_t *)calloc(1, sizeof(host_entry_t));
                if (!new_entry) {
                    perror("calloc");
                    exit(EXIT_FAILURE);
                }
                colon = strchr(optarg, ':');
                if (colon) {
                    *colon = '\0';
                    strncpy(new_entry->hostname, optarg, sizeof(new_entry->hostname) - 1);
                    new_entry->port = atoi(colon + 1);
                } else {
                    strncpy(new_entry->hostname, optarg, sizeof(new_entry->hostname) - 1);
                    new_entry->port = DEFAULT_PORT;
                }
                if (!hosts) {
                    hosts = tail = new_entry;
                } else {
                    tail->next = new_entry;
                    tail = new_entry;
                }
                break;
            case 't':
                timeout_sec = atoi(optarg);
                break;
            case 'v':
                verbose = 1;
                break;
            case 'h':
            default:
                usage(argv[0]);
        }
    }

    if (strlen(api_key) == 0 || !hosts) {
        usage(argv[0]);
    }

    if (verbose) {
        fprintf(stderr, "\n");
    }

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    tv.tv_sec = timeout_sec;
    tv.tv_usec = 0;
    setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, (const char *)&tv, sizeof(tv));

    snprintf(send_buf, sizeof(send_buf), "psurup %s", api_key);

    for (cur = hosts; cur; cur = cur->next) {
        memset(&hints, 0, sizeof(hints));
        hints.ai_family = AF_INET;
        hints.ai_socktype = SOCK_DGRAM;

        snprintf(port_str, sizeof(port_str), "%d", cur->port);

        if (getaddrinfo(cur->hostname, port_str, &hints, &res) != 0) {
            fprintf(stderr, "Could not resolve %s\n", cur->hostname);
            continue;
        }

        if (verbose) {
            addr = (struct sockaddr_in *)res->ai_addr;
            inet_ntop(AF_INET, &addr->sin_addr, ip_str, sizeof(ip_str));
            printf("127: %s %s %d\n", cur->hostname, ip_str, cur->port);
            printf("135: sending to host %s port %d\n", cur->hostname, cur->port);
        }

        sendto(sockfd, send_buf, strlen(send_buf), 0, res->ai_addr, res->ai_addrlen);

        addr_len = res->ai_addrlen;
        bytes = recvfrom(sockfd, recv_buf, sizeof(recv_buf) - 1, 0, res->ai_addr, &addr_len);

        if (bytes > 0) {
            recv_buf[bytes] = '\0';
            printf("%s:%d: %s", ip_str, cur->port, recv_buf);

        } else {
            printf("Timeout %s:%d\n", cur->hostname, cur->port);
        }

        if (verbose) {
            printf("268: freeing host %s\n", cur->hostname);
        }

        freeaddrinfo(res);
    }

    close(sockfd);
    return 0;
}

