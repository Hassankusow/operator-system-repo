#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <getopt.h>
#include <pwd.h>
#include <grp.h>
#include <time.h>
#include <errno.h>
#include <stdbool.h>
#include <utime.h>
#include <inttypes.h>
#include <zlib.h>
#include "arvik.h"


#define FILE_PERMISSIONS_NEW (S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH)
#define STD_ARCHIVE_NAME "stdin/stdout"


#define FOOTER_LEN 12

void print_long_toc(arvik_header_t *hdr, const char *crc_str);
void print_mode(mode_t mode);
void create_arvik_archive(int argc, char *argv[], char *archive_name);
void extract_arvik_archive(const char *archive_name);
const char *mode_to_str(mode_t mode);

typedef enum {
    MODE_NONE,
    MODE_CREATE,
    MODE_EXTRACT,
    MODE_SHORT_TOC,
    MODE_LONG_TOC
} arvik_mode_t;
int main(int argc, char *argv[]) {
    int opt;
    int mode_count = 0;
    int iarch = STDIN_FILENO;
    int result;

    arvik_mode_t mode = MODE_NONE;
    char *file_name = NULL;
    bool verbose = false;

    char archive_tag_buf[sizeof(ARVIK_TAG)] = {0};
    char footer_buf[FOOTER_LEN] = {0};
    arvik_header_t hdr;
    char name_buf[sizeof(hdr.arvik_name) + 1] = {0};
    size_t data_size = 0;
    char clean_name[sizeof(hdr.arvik_name)];
    size_t nlen;
    off_t skip;
    const char *crc_str = footer_buf;


    while ((opt = getopt(argc, argv, ARVIK_OPTIONS)) != -1) {
        switch (opt) {
            case 'h':
                    printf("Usage: arvik -[cxtvVf:h] archive-file file...\n");
                    printf("        -c           create a new archive file\n");
                    printf("        -x           extract members from an existing archive file\n");
                    printf("        -t           show the table of contents of archive file\n");
                    printf("        -f filename  name of archive file to use\n");
                    printf("        -V           Validate the crc value for the data\n");
                    printf("        -v           verbose output\n");
                    printf("        -h           show help text\n");
                    exit(EXIT_SUCCESS);

            case 'c':
                mode = MODE_CREATE;
                mode_count++;
                break;
            case 'x':
                mode = MODE_EXTRACT;
                mode_count++;
                break;
            case 't':
                mode = MODE_SHORT_TOC;
                mode_count++;
                break;
            case 'v':
                verbose = true;
                break;
            case 'V':
                //
                break;
            case 'f':
                if (!optarg) {
                        fprintf(stderr, "Error: -f option requires a filename argument.\n");
                        exit(INVALID_CMD_OPTION);
                }
                file_name = optarg;
                break;
            default:
                fprintf(stderr, "Unknown option: %c\n", opt);
                exit(INVALID_CMD_OPTION);
        }
    }
    if (file_name && file_name[0] == '-') {
            fprintf(stderr, "CHECKPOINT 1: file_name is another option\n");
            fprintf(stderr, "Error: -f requires a filename (not another option)\n");
            exit(INVALID_CMD_OPTION);
    }
    if (!file_name && (mode == MODE_EXTRACT || mode == MODE_SHORT_TOC || mode == MODE_LONG_TOC)) {
            fprintf(stderr, "CHECKPOINT 2: -f required for this mode\n");
            fprintf(stderr, "Error: -f option is required for this mode.\n");
            exit(INVALID_CMD_OPTION);
    }
    if (!file_name && mode != MODE_CREATE && mode != MODE_EXTRACT) {
            fprintf(stderr, "CHECKPOINT 3: -f required for this mode (again)\n");
            fprintf(stderr, "-f option requires a filename for this mode\n");
            exit(INVALID_CMD_OPTION);
    }
    if (mode_count != 1) {
            fprintf(stderr, "CHECKPOINT 4: mutually exclusive check failed\n");
            fprintf(stderr, "Options -c, -x, and -t are mutually exclusive.\n");
            exit(INVALID_CMD_OPTION);
    }
    if (!file_name && mode != MODE_CREATE && mode != MODE_EXTRACT) {
            fprintf(stderr, "CHECKPOINT 5: another -f missing check\n");
            fprintf(stderr, "-f option requires a filename for this mode\n");
            exit(INVALID_CMD_OPTION);
    }


    if (mode == MODE_SHORT_TOC && verbose) {
        mode = MODE_LONG_TOC;
    }

    if (mode == MODE_CREATE) {
        create_arvik_archive(argc, argv, file_name);
        return 0;
    }

    if (mode == MODE_EXTRACT) {
        extract_arvik_archive(file_name);
        return 0;
    }

    // TOC (-t / -tv)
    if (file_name) {
        iarch = open(file_name, O_RDONLY);
        if (iarch == -1) {
            perror("Error opening archive file");
            exit(EXIT_FAILURE);
        }
    }

    result = read(iarch, archive_tag_buf, strlen(ARVIK_TAG));
    if (result != (ssize_t)strlen(ARVIK_TAG) || strcmp(archive_tag_buf, ARVIK_TAG) != 0) {
        fprintf(stderr, "Not a valid ARVIK archive (bad tag)\n");
        if (iarch != STDIN_FILENO) close(iarch);
        exit(BAD_TAG);
    }

    

    while (read(iarch, &hdr, sizeof(hdr)) == sizeof(hdr)) {
        if (memcmp(hdr.arvik_term, ARVIK_TERM, sizeof(hdr.arvik_term)) != 0) {
            fprintf(stderr, "Bad header terminator. Exiting...\n");
            if (iarch != STDIN_FILENO) close(iarch);
            exit(TOC_FAIL);
        }
        data_size = strtoul(hdr.arvik_size, NULL, 10);
        skip = data_size + (data_size % 2 != 0 ? 1 : 0);

        snprintf(name_buf, sizeof(name_buf), "%.*s", (int)sizeof(hdr.arvik_name), hdr.arvik_name);
        name_buf[sizeof(name_buf) - 1] = '\0'; 
        
        for (int i = strlen(name_buf) - 1; i >= 0; i--) {
                if (name_buf[i] == '/') {
                        name_buf[i] = '\0';
                        break;
                }
        }
        if (mode == MODE_SHORT_TOC) {
                printf("%s\n", name_buf);
        }


        if (lseek(iarch, skip, SEEK_CUR) == (off_t)-1) {
            perror("Error skipping file data + padding");
            if (iarch != STDIN_FILENO) close(iarch);
            exit(EXIT_FAILURE);
        }

        if (read(iarch, footer_buf, sizeof(footer_buf)) != sizeof(footer_buf)) {
            perror("Error reading footer");
            if (iarch != STDIN_FILENO) close(iarch);
            exit(EXIT_FAILURE);
        } else if (memcmp(footer_buf + 10, ARVIK_TERM, 2) != 0) {
            fprintf(stderr, "Bad footer terminator. Exiting...\n");
            if (iarch != STDIN_FILENO) close(iarch);
            exit(TOC_FAIL);
        }
        if (mode == MODE_LONG_TOC) {
                snprintf(clean_name, sizeof(clean_name), "%.*s", (int)sizeof(hdr.arvik_name), hdr.arvik_name);
                nlen = strlen(clean_name);
                if (nlen > 0 && clean_name[nlen - 1] == '/') {
                        clean_name[nlen - 1] = '\0';
                }
                strncpy(hdr.arvik_name, clean_name, sizeof(hdr.arvik_name));
                hdr.arvik_name[sizeof(hdr.arvik_name) - 1] = '\0';
                crc_str = footer_buf;
                print_long_toc(&hdr, crc_str); 
        }
    }

    if (iarch != STDIN_FILENO) {
        close(iarch);
    }

    return 0;
}

void create_arvik_archive(int argc, char *argv[], char *archive_name) {
    int fd, src_fd, i;
    struct stat st;
    arvik_header_t hdr;
    arvik_footer_t footer;
    ssize_t bytes, written;
    uLong crc;
    char buffer[1024];
    char crc_buf[11];
    char clean_name[sizeof(hdr.arvik_name)];
    char *base;

    fd = STDOUT_FILENO;
    if (archive_name != NULL) {
        fd = open(archive_name, O_WRONLY | O_CREAT | O_TRUNC, 0644);
        if (fd < 0) {
            perror("Error opening archive");
            exit(CREATE_FAIL);
        }
    }

    if (write(fd, ARVIK_TAG, strlen(ARVIK_TAG)) != (ssize_t)strlen(ARVIK_TAG)) {
        perror("Error writing tag");
        exit(CREATE_FAIL);
    }

    for (i = optind; i < argc; ++i) {
        memset(&hdr, 0, sizeof(hdr));
        memset(&footer, 0, sizeof(footer));
        memset(buffer, 0, sizeof(buffer));
        memset(clean_name, 0, sizeof(clean_name));

        if (stat(argv[i], &st) != 0) {
            perror("stat");
            continue;
        }
        if (!S_ISREG(st.st_mode)) {
            fprintf(stderr, "Skipping non-regular file: %s\n", argv[i]);
            continue;
        }
        src_fd = open(argv[i], O_RDONLY);
        if (src_fd < 0) {
            perror("open");
            continue;
        }
        base = strrchr(argv[i], '/');
        base = (base != NULL) ? base + 1 : argv[i];
        strlcpy(clean_name, base, sizeof(clean_name));
        strlcat(clean_name, "/", sizeof(clean_name));
        strncpy(hdr.arvik_name, clean_name, sizeof(hdr.arvik_name));

        snprintf(hdr.arvik_size, sizeof(hdr.arvik_size), "%ld", (long)st.st_size);
        snprintf(hdr.arvik_uid, sizeof(hdr.arvik_uid), "%d", st.st_uid);
        snprintf(hdr.arvik_gid, sizeof(hdr.arvik_gid), "%d", st.st_gid);
        snprintf(hdr.arvik_mode, sizeof(hdr.arvik_mode), "%07o", st.st_mode & 07777);
        snprintf(hdr.arvik_date, sizeof(hdr.arvik_date), "%ld", (long)st.st_mtime);
        memcpy(hdr.arvik_term, ARVIK_TERM, sizeof(hdr.arvik_term));

        written = write(fd, &hdr, sizeof(hdr));
        if (written != sizeof(hdr)) {
            perror("write header");
            close(src_fd);
            continue;
        }

        crc = crc32(0L, Z_NULL, 0);
        while ((bytes = read(src_fd, buffer, sizeof(buffer))) > 0) {
            crc = crc32(crc, (Bytef *)buffer, bytes);
            if (write(fd, buffer, bytes) != bytes) {
                perror("write file content");
                break;
            }
        }
        close(src_fd);

        if (st.st_size % 2 != 0) {
            if (write(fd, "\n", 1) != 1) {
                perror("write padding");
            }
        }

        snprintf(crc_buf, sizeof(crc_buf), "0x%08lx", (unsigned long)crc);
        memset(&footer, 0, sizeof(footer));
        memcpy(footer.arvik_data_crc, crc_buf, 10);
        memcpy(footer.arvik_term, ARVIK_TERM, 2);

        if (write(fd, &footer, sizeof(footer)) != sizeof(footer)) {
            perror("write footer");
        }
    }

    if (fd != STDOUT_FILENO) {
        close(fd);
    }
}

void extract_arvik_archive(const char *archive_name) {
    int fd, out_fd, i;
    arvik_header_t hdr;
    arvik_footer_t footer;
    ssize_t bytes, bytes_written;
    uLong crc;
    char buffer[1024];
    size_t size, remaining, chunk;
    char safe_name[sizeof(hdr.arvik_name) + 1];
    struct utimbuf tbuf;
    char tag[sizeof(ARVIK_TAG)] = {0};
    char crc_buf[11];

    fd = STDIN_FILENO;
    if (archive_name != NULL) {
        fd = open(archive_name, O_RDONLY);
        if (fd < 0) {
            perror("open archive");
            exit(EXTRACT_FAIL);
        }
    }

    if (read(fd, tag, strlen(ARVIK_TAG)) != (ssize_t)strlen(ARVIK_TAG) || strcmp(tag, ARVIK_TAG) != 0) {
        fprintf(stderr, "Invalid archive tag\n");
        exit(BAD_TAG);
    }

    while (read(fd, &hdr, sizeof(hdr)) == sizeof(hdr)) {
        memset(safe_name, 0, sizeof(safe_name));
        strncpy(safe_name, hdr.arvik_name, sizeof(safe_name) - 1);
        for (i = strlen(safe_name) - 1; i >= 0; --i) {
            if (safe_name[i] == '/') {
                safe_name[i] = '\0';
                break;
            }
        }

        size = (size_t)strtol(hdr.arvik_size, NULL, 10);
        out_fd = open(safe_name, O_CREAT | O_WRONLY | O_TRUNC, strtol(hdr.arvik_mode, NULL, 8));
        if (out_fd < 0) {
            perror("create output");
            lseek(fd, size + (size % 2), SEEK_CUR);
            lseek(fd, sizeof(footer), SEEK_CUR);
            continue;
        }

        crc = crc32(0L, Z_NULL, 0);
        remaining = size;
        while (remaining > 0) {
            chunk = remaining > sizeof(buffer) ? sizeof(buffer) : remaining;
            bytes = read(fd, buffer, chunk);
            if (bytes <= 0) {
                break;
            }
            crc = crc32(crc, (Bytef *)buffer, bytes);
            bytes_written = write(out_fd, buffer, bytes);
            if (bytes_written != bytes) {
                break;
            }
            remaining -= bytes;
        }
        close(out_fd);

        if (size % 2 != 0) {
            lseek(fd, 1, SEEK_CUR);
        }

        if (read(fd, &footer, sizeof(footer)) == sizeof(footer)) {
            snprintf(crc_buf, sizeof(crc_buf), "0x%08lx", (unsigned long)crc);
            if (strncmp(footer.arvik_data_crc, crc_buf, 10) != 0) {
                fprintf(stderr, "*** CRC32 mismatch for %s\n", safe_name);
            }
        }

        tbuf.actime = time(NULL);
        tbuf.modtime = strtol(hdr.arvik_date, NULL, 10);
        utime(safe_name, &tbuf);
    }

    if (fd != STDIN_FILENO) {
        close(fd);
    }
}


void print_long_toc(arvik_header_t *hdr, const char *crc_str) {
    char name_buf[sizeof(hdr->arvik_name) + 1];
    char uid_buf[16], gid_buf[16], size_buf[16], mode_buf[16], date_buf[32];
    char mtime_buf[64];
    time_t mtime;
    struct tm *tm;
    struct passwd *pw;
    struct group *gr;

    // Clean name (remove trailing slash)
    snprintf(name_buf, sizeof(name_buf), "%.*s", (int)sizeof(hdr->arvik_name), hdr->arvik_name);
    name_buf[sizeof(name_buf) - 1] = '\0';
    for (int i = strlen(name_buf) - 1; i >= 0; i--) {
        if (name_buf[i] == '/') {
            name_buf[i] = '\0';
            break;
        }
    }

    // Copy strings safely
    snprintf(uid_buf, sizeof(uid_buf), "%.*s", (int)sizeof(hdr->arvik_uid), hdr->arvik_uid);
    snprintf(gid_buf, sizeof(gid_buf), "%.*s", (int)sizeof(hdr->arvik_gid), hdr->arvik_gid);
    snprintf(size_buf, sizeof(size_buf), "%.*s", (int)sizeof(hdr->arvik_size), hdr->arvik_size);
    snprintf(mode_buf, sizeof(mode_buf), "%.*s", (int)sizeof(hdr->arvik_mode), hdr->arvik_mode);
    snprintf(date_buf, sizeof(date_buf), "%.*s", (int)sizeof(hdr->arvik_date), hdr->arvik_date);

    // Parse UID/GID
    pw = getpwuid(atoi(uid_buf));
    gr = getgrgid(atoi(gid_buf));

    // Format mtime
    mtime = (time_t)strtol(date_buf, NULL, 10);
    tm = localtime(&mtime);
    strftime(mtime_buf, sizeof(mtime_buf), "%b %e %R %Y", tm);

    // Print fields with tight spacing
    printf("file name: %s\n", name_buf);
    printf("    mode:       %s\n", mode_to_str((mode_t)strtol(mode_buf, NULL, 8))+1);
    printf("    uid:    %13s  %s\n", uid_buf, pw ? pw->pw_name : uid_buf);
    printf("    gid:    %13s  %s\n", gid_buf, gr ? gr->gr_name : gid_buf);
    printf("    size:   %13s  bytes\n", size_buf);
    printf("    mtime:      %s\n", mtime_buf);
    printf("    data csc32: %.10s\n", crc_str);
}

const char *mode_to_str(mode_t mode) {
    static char str[11];
    str[0] = S_ISDIR(mode) ? 'd' : S_ISLNK(mode) ? 'l' : '-';
    str[1] = (mode & S_IRUSR) ? 'r' : '-';
    str[2] = (mode & S_IWUSR) ? 'w' : '-';
    str[3] = (mode & S_IXUSR) ? 'x' : '-';
    str[4] = (mode & S_IRGRP) ? 'r' : '-';
    str[5] = (mode & S_IWGRP) ? 'w' : '-';
    str[6] = (mode & S_IXGRP) ? 'x' : '-';
    str[7] = (mode & S_IROTH) ? 'r' : '-';
    str[8] = (mode & S_IWOTH) ? 'w' : '-';
    str[9] = (mode & S_IXOTH) ? 'x' : '-';
    str[10] = '\0';
    return str;
}

